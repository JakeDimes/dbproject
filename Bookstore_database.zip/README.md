### Database Final Project: Working Database Files

### Organizaiton
- Create Folder: TXT Files relating to creating the database schema and views
- Data Folder: TXT Files relating to adding data to the database
- Queries Folder: TXT files relating to queries to perform on the database

### Important Note
The Bookstore.db binary is at the stage where the Database schema and data has been loaded into it. I.E, the code in the files in the
Create and Data directories have been run and the changes have been saved. 
